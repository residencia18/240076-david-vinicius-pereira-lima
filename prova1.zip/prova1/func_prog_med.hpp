//cabecalho das funcoes do programa de medico
#include <iostream>
#include <string>
#include <vector>

#include "classes.hpp"

using namespace std;

void incluirMedico(Medicos * medicos);
void excluirMedico(Medicos * medicos);
void alterarMedico(Medicos * medicos);
void listarMedicos(Medicos * medicos);
void localizarMedico(Medicos * medicos);
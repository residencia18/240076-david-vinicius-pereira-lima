//cabecalho das funcoes do programa de paciente
#include <iostream>
#include <string>
#include <vector>

#include "classes.hpp"

using namespace std;

void incluirPaciente(Pacientes * pacientes);
void excluirPaciente(Pacientes * pacientes);
void alterarPaciente(Pacientes * pacientes);
void listarPacientes(Pacientes * pacientes);
void localizarPaciente(Pacientes * pacientes);
